from datetime import datetime, timedelta
print(datetime.now)

